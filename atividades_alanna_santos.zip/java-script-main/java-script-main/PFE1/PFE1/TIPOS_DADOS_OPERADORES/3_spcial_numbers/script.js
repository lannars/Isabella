console.log(typeof Infinity);
console.log(typeof -Infinity);
console.log(typeof NaN); //Not a Number
