alert("Olá turma!");
console.log("Quarta-feira chvosa!");