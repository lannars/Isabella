let esc = prompt("escolha algo do cardapio: ")
switch (esc) {
    case "Lanche":
        console.log("Escolheu lanche");
        break;
    case "Pizza":
        console.log("Escolheu pizza");
        break;
    case "Brigadeiro":
        console.log("Brigadeiro");
        break;
    default:
        console.log("Não encontrei nada que gosto");
}