let nome = prompt("Qual o seu nome?");
console.log(nome)


let num1 = Number(prompt("Digite um número: "))
let num2 = Number(prompt("Digite um número: "))
let soma = num1 + num2
console.log(`A soma do número é ${soma}`);

