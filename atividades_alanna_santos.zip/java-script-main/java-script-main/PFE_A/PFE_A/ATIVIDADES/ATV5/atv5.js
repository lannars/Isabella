alert("Boas vindas!");

let idade = prompt("Qual a sua idade?");
if(idade >= 18){
    console.log("Maior de idade")
}else{
    console.log("Menor de idade")
}




