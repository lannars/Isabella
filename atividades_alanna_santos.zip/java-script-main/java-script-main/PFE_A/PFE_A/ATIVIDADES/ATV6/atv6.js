let aleatorio = Math.floor(Math.random() * 100 ) + 1;
console.log(aleatorio);

let num = Math.sqrt(255)
console.log(num);






