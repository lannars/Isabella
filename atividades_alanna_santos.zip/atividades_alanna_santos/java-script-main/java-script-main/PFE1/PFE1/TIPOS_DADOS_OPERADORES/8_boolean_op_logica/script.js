console.log(5 > 3 && 3 ==2);//f
console.log(3 == 3 && "Lucas" == "Lucas");//v
console.log('Felipe' == 'João' || false);
console.log(!(!(true && true)));//v
console.log(true && false);//f
console.log(false || true);//v













