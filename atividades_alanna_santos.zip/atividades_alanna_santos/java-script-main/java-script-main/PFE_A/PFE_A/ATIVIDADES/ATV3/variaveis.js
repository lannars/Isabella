let idade = 16;
console.log("A idade é 16");

var nome = 'Alanna';
console.log(nome);

const pi = 3.1415926589
console.log(pi);


