let maior = Math.max(6, 12, 20, 50, 100)
console.log(maior);

let menor = Math.min(6, 12, 20, 50, 100)
console.log(menor);

let arredondar = Math.round(3, 14151926);
console.log(arredondar);

let arredondar_cima = Math.ceil(5.75);
console.log(arredondar_cima);

