let nome3 = 'teste';
let $nome = 'teste2';
console.log($nome);

let _nome = 'teste3';
console.log(_nome);