let a = 10;
function multiplicar(x, y){
    let a = x * y
    if (a>10){
        let a = 0;
        a++;
        console.log('dentro if: ' + a);
    }
    console.log('Dentro função: ' + a);
}
console.log('Fora função: ' + a);
multiplicar(3, 7);





