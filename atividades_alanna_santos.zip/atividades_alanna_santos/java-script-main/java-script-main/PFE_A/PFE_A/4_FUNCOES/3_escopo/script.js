let y = 18;

function imprimir() {
  let y = 150;
  console.log(y);
}
imprimir();
console.log(y);
