function recusao(n) {
    if (n - 1 < 2) {
        console.log('Recursão parou!');
    }else if(n % 2 != 0){
        console.log("Número impar " + n);
    }else{
        console.log('Número par ' + n);
        recusao(n);
    }
}

function fibonati(n){
    if (n = 0)
    console.log();
}














