let consoleTeste = () => {
    console.log("Olá Turma 2-IDS!");
};
consoleTeste();

let soma = (n1, n2) => {
    return n1 + n2;
}
console.log(soma(2 + 7));








