function multiplicacao(n1, n2, n3){
    return n1 * n2 * n3;
}
console.log(multiplicacao(2, 3, 4));

function podeDirigir(idade, cnh){
    if(idade >= 18 && cnh == true){
        console.log("Pode dirigir!");
    }else{
        console.log('Não pode dirigir');
    }
}
console.log(podeDirigir(19, true));
console.log(podeDirigir(20, false));
console.log(podeDirigir(13, true));




