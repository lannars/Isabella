function imprimirNoConsole(){
    console.log('Olá turma!');
}
imprimirNoConsole();


function imprimirNoConsole(num) {
    console.log('O Numero é =' + num);
    
}
imprimirNoConsole(5);


function Soma(soma){
    console.log('A soma dos números é: ' + soma)
}
Soma(5+5);


const numeroAleatorio = function (){
    console.log(Math.random());
};
numeroAleatorio();
numeroAleatorio();
numeroAleatorio();