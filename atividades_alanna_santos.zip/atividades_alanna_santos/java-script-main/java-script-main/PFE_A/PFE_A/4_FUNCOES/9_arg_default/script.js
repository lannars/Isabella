function potencia(base, exp = 2){
    return Math.pow(base, exp);
}

console.log(potencia(2));// 4
console.log(potencia(2, 2));// 4
console.log(potencia(2, 3));// 8













