console.log(typeof "Lívia");
console.log(typeof 10 );
console.log(6 > 4 && 6 < 4);
console.log(null);
console.log(undefined);




